# Everlane 

Description: Everlane Online Shopping system is a strategy whereby customers straightforwardly purchase clothes, services, and so forth. From the Everlane supplier interactively in real-time without an intermediate facility over the internet. Customers can search multiple products at the same time, comparing material quality, sizes, and pricing instantaneously

Code Structure
  - Code structure follows the MVC process
    




Manage Project's Tool:
  - IntelliJ
  - AWS
  - MySQL
  - GitHub
  - Git Kraken
  - Git Lab
  - Figma
  - Google Sheet
  - Google Doc
  - Notion

How folder work:
  - "Database" contains script to run the database in MySQL
  - "Lib" contains the library used in IntelliJ
  - "Everlane" contains the main code
